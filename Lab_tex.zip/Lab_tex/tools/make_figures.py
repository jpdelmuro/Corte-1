#!/usr/bin/env python3
"""Rebuild the original manuscript diagrams (requires matplotlib)."""
from pathlib import Path
import csv
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, RegularPolygon, Circle

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'pdf.fonttype':42})
ink='#163149';blue='#1f6188';light='#edf4f8';green='#267164'

fig,ax=plt.subplots(figsize=(11,4.4))
ax.set(xlim=(0,11),ylim=(0,4.4));ax.axis('off')
def box(x,y,w,h,title,body,color=blue):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.035',
                 linewidth=1.2,edgecolor=color,facecolor=light))
    ax.text(x+w/2,y+h-.22,title,ha='center',va='center',weight='bold',color=ink,fontsize=11)
    ax.text(x+w/2,y+.40,body,ha='center',va='center',color=ink,fontsize=10.2,linespacing=1.25)
def arrow(a,b,label=None,style='-',color=ink):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,
                  linewidth=1.15,linestyle=style,color=color))
    if label:ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.14,label,ha='center',va='bottom',fontsize=9,color=color)
xs=[.15,2.35,4.55,6.75,8.95];w=1.85
box(xs[0],2.85,w,1.12,'People + camera','RGB frames\nManual / Stop')
box(xs[1],2.85,w,1.12,'Host PC','Landmarks + state\nIK / limits / GUI')
box(xs[2],2.85,w,1.12,'ESP32-C3','Checks + watchdog\nServo calibration')
box(xs[3],2.85,w,1.12,'2 x PCA9685','0x40 and 0x41\n32 PWM signals')
box(xs[4],2.85,w,1.12,'SOFIA panel','16 two-axis units\n32 servos')
for i,label in enumerate(['frames','Wi-Fi','I2C','PWM']):
    arrow((xs[i]+w,3.42),(xs[i+1],3.42),label)
ax.plot([5.48,5.48,3.28],[2.85,2.50,2.50],color=blue,lw=1.1,ls='--')
arrow((3.28,2.50),(3.28,2.84),style='--',color=blue)
ax.text(4.4,2.64,'ACK / state / faults',ha='center',color=blue,fontsize=10)
box(.3,.35,3.25,1.18,'PC-side functions','Owner selection / gesture latch\nFiltering / logging / virtual panel')
box(4.5,.35,2.3,1.18,'Optional expansion','3.3 V transceiver\nRS-485 to other panels',green)
ax.plot([6.25,6.25,5.48],[2.85,2.18,2.18],color=green,lw=1.1)
arrow((5.48,2.18),(5.48,1.55),color=green)
ax.text(5.25,1.88,'serial',ha='right',fontsize=9,color=green)
box(7.3,.35,3.3,1.18,'Power distribution','SERVO_5V -> actuator branches\nELEC_5V -> LOGIC_3V3',green)
arrow((9.88,1.57),(9.88,2.83),color=green)
ax.text(10.1,2.12,'servo\npower',fontsize=9,color=green,va='center')
ax.plot([8.6,8.6,5.98],[1.57,1.77,1.77],color=green,lw=1.1)
arrow((5.98,1.77),(5.98,2.83),color=green)
arrow((7.6,1.77),(7.6,2.83),color=green)
ax.text(8.35,2.27,'3.3 V\nlogic',fontsize=9,color=green,ha='center')
ax.text(9.15,.12,'Common GND; return sized for load',fontsize=9,color=green,ha='center')
ax.text(.3,2.07,'Commanded pose is not measured pose.',fontsize=10,color=ink)
fig.subplots_adjust(0,0,1,1);fig.savefig(OUT/'architecture.pdf');plt.close(fig)

coords=list(csv.DictReader((ROOT/'supplementary/panel_coordinates.csv').open()))
fig,(ax,ay)=plt.subplots(1,2,figsize=(10,4.1),gridspec_kw={'width_ratios':[1.05,1]})
for row in coords:
    x=float(row['base_x_mm']);y=float(row['base_y_mm'])
    ax.add_patch(RegularPolygon((x,y),6,radius=49.31,orientation=math.pi/6,
                    facecolor=light,edgecolor=blue,lw=1.25))
    ax.text(x,y,row['unit_id'],ha='center',va='center',color=ink,fontsize=10)
ax.scatter([0],[0],color=green,marker='+',s=90,lw=1.5,zorder=5)
ax.annotate('Wave origin (centroid)',xy=(0,0),xytext=(-280,-258),fontsize=9,
            color=green,arrowprops={'arrowstyle':'->','color':green})
top=float(coords[0]['base_y_mm'])
ax.annotate('',xy=(0,top+67),xytext=(-120,top+67),arrowprops={'arrowstyle':'<->','color':ink})
ax.text(-60,top+77,'120 mm',ha='center',fontsize=10)
ax.set(xlim=(-310,310),ylim=(-290,315),xlabel='Global x (mm)',ylabel='Global y (mm)')
ax.set_aspect('equal');ax.spines[['top','right']].set_visible(False);ax.tick_params(labelsize=9)
ax.set_title('(a) Honeycomb base layout',loc='left',fontsize=12,pad=14,color=ink)
ay.set(xlim=(-.3,5.5),ylim=(-.45,4.8));ay.axis('off')
base=(.5,.3);pivot=(.5,1.5);tip=(2.,2.9);target=(3.6,4.4)
ay.plot([base[0],pivot[0]],[base[1],pivot[1]],color=ink,lw=4)
ay.plot([pivot[0],tip[0]],[pivot[1],tip[1]],color=blue,lw=4)
ay.plot([tip[0],target[0]],[tip[1],target[1]],color=blue,lw=1.5,ls='--')
for p,label,off in [(base,r'$b_i$',(-.4,-.1)),(pivot,r'$o_{2i}$',(-.5,.1)),(tip,r'$o_{3i}$',(.25,0))]:
    ay.scatter(*p,s=45,color=ink,zorder=5);ay.text(p[0]+off[0],p[1]+off[1],label,fontsize=12,color=ink)
ay.scatter(*target,s=70,color=green);ay.text(target[0]+.25,target[1],r'Target $p$',fontsize=11,color=green)
ay.text(.72,.80,'h = 60 mm',fontsize=10,color=ink)
ay.text(1.2,1.68,'l = 100 mm',fontsize=10,color=blue,rotation=40)
ay.annotate('',xy=(.5,3.1),xytext=pivot,arrowprops={'arrowstyle':'->','color':'#888','linestyle':'--'})
ay.text(.23,3.22,'Local z',fontsize=10,color='#666')
ay.annotate('',xy=(4.65,1.1),xytext=(3.8,1.1),arrowprops={'arrowstyle':'->','color':ink})
ay.annotate('',xy=(3.8,2.0),xytext=(3.8,1.1),arrowprops={'arrowstyle':'->','color':ink})
ay.text(4.75,1.,'x',fontsize=11);ay.text(3.7,2.12,'z',fontsize=11)
ay.text(2.6,-.03,'Illustrative x-z view\nPointing, not target contact',ha='center',va='top',fontsize=9,color=ink)
ay.set_title('(b) Ideal two-axis pointing model',loc='left',fontsize=12,pad=14,color=ink)
fig.tight_layout(w_pad=2);fig.savefig(OUT/'geometry.pdf',bbox_inches='tight');plt.close(fig)
print('Generated architecture.pdf and geometry.pdf')
