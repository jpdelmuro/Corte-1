#!/usr/bin/env python3
"""Reproducible software-only microtests; Python 3 standard library only.

This is an independent implementation of the equations in the manuscript,
not the missing original MATLAB program or the installed robot controller.
Run from any directory. Outputs are written under supplementary/.
"""
import csv
import json
import math as m
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "supplementary"
OUT.mkdir(exist_ok=True)

def dot(a, b):
    return sum(x*y for x, y in zip(a, b))

def norm(a):
    return m.sqrt(dot(a, a))

def sub(a, b):
    return tuple(x-y for x, y in zip(a, b))

def wrap(a):
    return (a+m.pi) % (2*m.pi)-m.pi

def direction(q):
    a, b = q
    return (m.sin(b), -m.cos(b)*m.sin(a), m.cos(a)*m.cos(b))

def solve(v, previous=(0., 0.), limit=m.pi/2):
    d = norm(v)
    if d < 1e-8:
        return previous, "zero_range_hold"
    u = tuple(x/d for x in v)
    if m.hypot(u[1], u[2]) < 1e-6:
        candidate = (previous[0], m.copysign(m.pi/2, u[0]))
        if all(abs(x) <= limit+1e-12 for x in candidate):
            return candidate, "pole_preserve_q1"
        return previous, "unreachable_hold"
    b = m.asin(max(-1., min(1., u[0])))
    a = m.atan2(-u[1], u[2])
    branches = [(wrap(a), wrap(b)), (wrap(a+m.pi), wrap(m.pi-b))]
    candidates = [q for q in branches if all(abs(x) <= limit+1e-12 for x in q)]
    if not candidates:
        return previous, "unreachable_hold"
    return min(candidates, key=lambda q: sum(wrap(x-y)**2 for x,y in zip(q,previous))), "reachable"

def write_csv(name, columns, rows):
    with (OUT/name).open("w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(columns)
        writer.writerows(rows)

# Row-major IDs, top row first; centroid is exactly the global origin.
pitch = 120.
row_sizes = (3, 4, 5, 4)
mean_row = sum(r*n for r,n in enumerate(row_sizes))/16
xy = [(pitch*(j-(n-1)/2), (mean_row-r)*m.sqrt(3)*pitch/2)
      for r,n in enumerate(row_sizes) for j in range(n)]
write_csv("panel_coordinates.csv", ["unit_id", "base_x_mm", "base_y_mm", "base_z_mm"],
          [(i+1,x,y,0.) for i,(x,y) in enumerate(xy)])

T = 20/12
records = []
previous = [(0.,0.) for _ in xy]
for k in range(50):
    t = k/30
    p = (180*m.cos(2*m.pi*t/T), 130*m.sin(2*m.pi*.7*t/T),
         220+50*m.sin(2*m.pi*.5*t/T))
    for i,(x,y) in enumerate(xy):
        v = sub(p,(x,y,60.))
        q,status = solve(v, previous[i])
        previous[i] = q
        u = tuple(a/norm(v) for a in v)
        n = direction(q)
        err = m.degrees(m.acos(max(-1.,min(1.,dot(u,n)))))
        cross = (u[1]*n[2]-u[2]*n[1],u[2]*n[0]-u[0]*n[2],u[0]*n[1]-u[1]*n[0])
        stable_error = m.degrees(m.atan2(norm(cross),dot(u,n)))
        records.append((k,t,i+1,*p,*map(m.degrees,q),status,err,stable_error))
write_csv("kinematic_microtest.csv", ["sample", "time_s", "unit_id", "target_x_mm",
          "target_y_mm", "target_z_mm", "q1_deg", "q2_deg", "status",
          "acos_direction_error_deg", "atan2_direction_error_deg"], records)
assert len(records)==800 and all(r[8]=="reachable" for r in records)
assert max(r[9] for r in records) < 1e-4

prev = (m.radians(12),m.radians(5))
boundary_inputs = [("coincident",(0.,0.,0.),"zero_range_hold"),
                   ("positive_pole",(1.,0.,0.),"pole_preserve_q1"),
                   ("negative_pole",(-1.,0.,0.),"pole_preserve_q1"),
                   ("behind_panel",(0.,0.,-1.),"unreachable_hold"),
                   ("near_pole",(1.,1e-8,1e-8),"pole_preserve_q1"),
                   ("forward",(0.,0.,1.),"reachable")]
boundary=[]
for name,v,expected in boundary_inputs:
    q,status=solve(v,prev)
    assert status==expected
    if status.endswith("hold"): assert q==prev
    if status=="pole_preserve_q1": assert q[0]==prev[0]
    boundary.append((name,*v,*map(m.degrees,q),status,"PASS"))
write_csv("boundary_microtest.csv", ["case","vx","vy","vz","q1_deg","q2_deg","status","verdict"],boundary)

# EMA with a separate rate limiter. The signal is synthetic, not camera data.
dt=1/30
alpha=1-m.exp(-dt/.1)
ema=0.
command=0.
filter_rows=[]
for k in range(60):
    ema=alpha*30+(1-alpha)*ema
    last=command
    command += max(-90*dt,min(90*dt,ema-command))
    filter_rows.append(((k+1)*dt,30.,ema,command,command-last))
assert max(abs(r[4]) for r in filter_rows)<=3.+1e-10
write_csv("filter_microtest.csv",["time_s","reference_deg","ema_deg","command_deg","increment_deg"],filter_rows)

# Geometric screening of the proposed heart wave only. No links or thickness.
A=m.radians(5)
f=.5
wavelength=240.
minimum_gap=1e9
wave_rows=[]
for k in range(181):
    t=k/30
    centers=[]
    for i,(x,y) in enumerate(xy):
        rho=m.hypot(x,y)
        w=m.sin(2*m.pi*f*t-2*m.pi*rho/wavelength)
        q=(-A*y/rho*w,A*x/rho*w) if rho else (0.,0.)
        n=direction(q)
        centers.append((x+100*n[0],y+100*n[1],60+100*n[2]))
        wave_rows.append((t,i+1,rho,*map(m.degrees,q)))
    for i in range(16):
        for j in range(i):
            minimum_gap=min(minimum_gap,norm(sub(centers[i],centers[j]))-98.62)
write_csv("heart_wave_microtest.csv",["time_s","unit_id","radius_mm","q1_deg","q2_deg"],wave_rows)
assert minimum_gap>=2.

prescale=round(25e6/(4096*50))-1
metrics={
    "evidence_type":"software-only independent reconstruction; no physical measurements",
    "sampling":"t=k/30 s, k=0,...,49; T=20/12 s",
    "layout":"centroid-centered rows 3,4,5,4; 120 mm pitch; see panel_coordinates.csv",
    "kinematic_samples":len(records),
    "maximum_acos_error_deg":max(r[9] for r in records),
    "mean_acos_error_deg":sum(r[9] for r in records)/len(records),
    "maximum_stable_error_deg":max(r[10] for r in records),
    "unreachable_samples":sum(r[8]!="reachable" for r in records),
    "boundary_cases_passed":len(boundary),
    "ema_alpha":alpha,
    "maximum_command_increment_deg":max(abs(r[4]) for r in filter_rows),
    "step_95_percent_time_s":next(r[0] for r in filter_rows if r[3]>=28.5),
    "heart_wave_minimum_sphere_gap_mm":minimum_gap,
    "heart_wave_samples":181,
    "heart_wave_duration_s":6.,
    "nominal_pwm_prescale":prescale,
    "nominal_pwm_frequency_hz":25e6/(4096*(prescale+1)),
    "nominal_pwm_tick_us":1e6*(prescale+1)/25e6,
    "assertions":"PASS"
}
(OUT/"numerical_metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")
(OUT/"numerical_values.tex").write_text(
    "% Generated by tools/numerical_checks.py; numerical checks only.\n"
    +f"\\newcommand{{\\IKMax}}{{{metrics['maximum_acos_error_deg']:.2e}}}\n"
    +f"\\newcommand{{\\IKMean}}{{{metrics['mean_acos_error_deg']:.2e}}}\n"
    +f"\\newcommand{{\\WaveGap}}{{{minimum_gap:.2f}}}\n"
    +f"\\newcommand{{\\StepTime}}{{{metrics['step_95_percent_time_s']:.2f}}}\n")
print(json.dumps(metrics,indent=2))
