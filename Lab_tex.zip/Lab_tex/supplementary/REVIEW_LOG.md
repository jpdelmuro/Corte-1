# SOFIA document-preparation and decision log

Record date: 2026-09-21. Associated manuscript: v0.1.

This is a traceable record of the present document review and numerical
work, prepared for incorporation into the team's official logbook. It is
not a retrospective account of laboratory sessions. Source-document dates
identify documents, not dates on which a particular team member performed
an experiment. Technical ownership below identifies a discipline requiring
review; it does not assign historical contributions to a named person.

| ID | Activity / observation | Evidence | Decision / reflection | Status / team review |
| --- | --- | --- | --- | --- |
| L01 | Review the architecture and stage checklist | Dossier pp. 1-5; checklist pp. 1, 3 | Define unit as one mechanism and panel as sixteen units; focus on Introduction and Materials and Methods | Completed documentary review; confirm terminology |
| L02 | Compare the two Assignment 1 reports | Identical SHA-256 hashes; six embedded images on p. 2 | Treat them as one source. Text still refers to reserved images; screenshots are actually present | Completed |
| L03 | Review the computational-systems brief | Brief pp. 7, 12 | Include five classes, at least three dynamic classes, and 1/2/3-person evaluation | Vocabulary proposed for team approval |
| L04 | Select the interaction opportunity | Project context plus current sources | Persistent heart gesture triggers a centroid-outward wave, with visible state and explicit stop | Proposed design; behavior test pending |
| L05 | Compare literature | Bibliography and literature_matrix.csv | Use inFORM as an interaction precedent; distinguish perception frameworks from mechanism/workspace work | Completed review; no superiority claimed |
| L06 | Check electrical interfaces | ESP32-C3 datasheet Secs. 3, 5.2; PCA9685 Secs. 7.1, 7.3.5; TI family datasheet | Separate 5 V power and 3.3 V logic; review boot pins; two driver addresses; candidate 3.3 V RS-485 part | Electrical/firmware review and measurement pending |
| L07 | Reconcile MG90S source inconsistencies | Component assessment and Tower Pro page | Use 4.8 V torque datum only; flag higher-voltage discrepancy; do not invent current or pulse endpoints | Mechanical/electrical bench work pending |
| L08 | Clarify kinematics and exceptional cases | Kinematics slides pp. 9-12; numerical_checks.py | Handle zero target range and angular poles separately; hold unreachable requests; verify mounting rotation | Numerical checks executed; hardware mapping pending |
| L09 | Execute M1 | kinematic_microtest.csv; boundary_microtest.csv | 800 directions within numerical criterion; six boundary cases pass | Software only |
| L10 | Execute M2 | filter_microtest.csv | Synthetic 30-degree step has maximum 3-degree command increment at 30 Hz | Software only; no physical servo lag measured |
| L11 | Execute M3 | heart_wave_microtest.csv; numerical_metrics.json | Sampled panel-sphere gap remains above 2 mm at 5-degree amplitude | Software screen only; no link/cable/transition clearance proof |
| L12 | Define acceptance, instruments, acquisition, and risk closure | Manuscript Tables III, VI, VII; blank CSV acquisition forms | Separate proposed thresholds from measurements; stage bench integration | Protocol drafted; no physical or human tests executed |
| L13 | Prepare LaTeX article and original figures | Main TEX, bibliography, figures, numerical outputs | Preserve supplied IEEE class and English-only article; remove instructional placeholders | Compiled and visually reviewed |
| L14 | Prepare authorship/version record | AUTHORS.md and manuscript version | Carry forward names but do not invent individual roles, author approval, or conflict declarations | Team confirmation pending |
| L15 | Repository registration | User's current instruction | Defer all GitHub actions; keep a local version label and package manifest | Explicitly pending |

## Items to transfer into the official logbook

1. Attach the manuscript version, package hash, and numerical output files.
2. Record who reviews each design decision and the actual review date.
3. Confirm or revise the gesture vocabulary, host architecture, and thresholds.
4. Attach real bench waveforms, camera metrics, and calibration files when collected.
5. Record deviations, failed tests, and design changes, including their evidence.
6. Confirm individual contributions, conflict statements, and later repository registration.

## Blank entry structure for the next laboratory session

- Actual session date and time:
- Named participants and roles:
- Goal and requirement/test IDs:
- Hardware/software configuration and version:
- Procedure and instruments:
- Raw evidence files:
- Observations (including failures):
- Acceptance verdict and rationale:
- Design decision/change:
- Next action, responsible person, and review date:

No blank field above represents a completed activity.
