# Source register and evidence audit

Review date: 2026-09-21. Main paper version: 0.1.

## Project evidence and exact locations

| BibTeX key | Supplied filename | Relevant location | Use and limit |
| --- | --- | --- | --- |
| sofia_arch | Arquitectura y Desarrollo SOFIA.pdf | pp. 1-5 | Topology, dimensions, electronics, power names, reference BOM |
| prior_report | SOFIA_Asignacion1_IEEE_Report (3).pdf | pp. 1-2 | Prior numerical results and six embedded images; original MATLAB source absent |
| prior_report | SOFIA_Asignacion1_IEEE_Report-1 (1).pdf | pp. 1-2 | Byte-identical copy; not independent replication |
| component_review | Análisis de componentes - Laboratorio (1).pdf | Tables I-III | Component assessment; unresolved current, torque, calibration |
| sc_brief | LABDST (SOFIA) - O26 - Definición de Eje Técnico de SC.pdf | pp. 7-9, 12-14 | Windows host, five postures, three dynamic, multiple people, GUI, communications |
| dlab_checklist | Lista de Cotejo D-Lab - Sofia.pdf | pp. 1, 3 | Required sections and traceability |
| kinematics | Modelado cinemático.pdf | pp. 9-12 | Rx(q1)Ry(q2), inverse equations, pole singularity |
| filters | Aplicación de Filtros.pdf | pp. 6, 9, 18, 24, 30 | Open-loop reference conditioning |
| modbus_course | Protocolo ModBus.pdf | pp. 2-14 | Addressing, CRC, half-duplex and faults |
| hexapod | applsci-14-08171.pdf | Kinematics and conclusions | Different robot; angle handling precedent |
| workspace | applsci-15-05383.pdf | Model, feasibility, conclusions | Planar constraints; not SOFIA collision proof |
| parallelogram | technologies-13-00404.pdf | Boundary analysis, discussion, conclusions | Mechanism-specific workspace |

## Additional context

The methodology, course introduction, study guide, reporting guidance,
BOM guidance, drawing sheets, Modbus flowcharts and exercise code are
contextual resources, not team experimental evidence. The course-content
workbook is not treated as experimental data. The water-use paper
(technologies-14-00223-v2.pdf) was screened by topic and abstract and
excluded from the direct technology comparison. Its classification metrics
are not SOFIA gesture results. No native CAD assembly was included in this
upload. Nominal drawing dimensions require physical registration.

## External primary sources checked

- Espressif ESP32-C3 Datasheet v2.4: Secs. 3 and 5.2.
- NXP PCA9685 Rev. 4: Secs. 7.1, 7.3.5; Table 14.
- Tower Pro MG90S product specification. Its higher-voltage torque entry
  says 6.6 V while the course uses 6.0 V; the paper avoids that disputed point.
- Texas Instruments SN65HVD7x, SLLSE11H, revised March 2019.
- Google AI Edge Python Pose and Hand Landmarker guides.
- Author-hosted inFORM full paper; MediaPipe Hands and OpenPose arXiv papers.

Full URLs are in bibliography.bib. Access date: 2026-09-21.
No GitHub repository/account operation or external message was performed.

## Reconciliations

1. Sixteen two-servo units need 32 signals; this resolves a 16-servo textual
   inconsistency in the course introduction using the detailed architecture BOM.
2. Both Assignment 1 PDFs are identical and do include images, despite old
   placeholder wording in their captions.
3. Near-zero simulation error does not mean near-zero physical error.
4. Both zero range and angular pole singularities are handled in the new script.
5. The modeled 60/100 mm offsets and +/-90-degree interval are simulation
   inputs, not new measurements of the mechanism.
6. Relative landmark depth is not absolute camera-to-panel distance.
7. Visible project history motivates the heart latch. The current HTML
   prototype was not audited or benchmarked in this task.

## Uploaded input hashes

- `Análisis de componentes - Laboratorio (1).pdf`: `428e3e513a499ef59301ee5570d3954fae450343e9fbb9eb31fac250891c0ec2`
- `SOFIA_Asignacion1_IEEE_Report (3).pdf`: `c28299d34cf14b94e4c588dec7daf87170528e8b3adbb786ca2e725eec5540e2`
- `SOFIA_Asignacion1_IEEE_Report-1 (1).pdf`: `c28299d34cf14b94e4c588dec7daf87170528e8b3adbb786ca2e725eec5540e2`
- `plantilla_IEEE_LabDST.zip`: `1f85146e614b9322512af3ca9b8abfb2e482fcac13623f195bcfa8d4e8ccf8cd`
- `temas_lab.rar`: `874aad7caa4ea75787cd5e363dfde9360f8bc51852a28074962ef6f887fb13d0`

## Course archive inventory

- `Análisis de componentes de Hardware.pdf`
- `Aplicación de Filtros.pdf`
- `Arquitectura y Desarrollo SOFIA.pdf`
- `Borrador 3 - Tabla de Contenido - LabDST - Sofia.xlsx`
- `Catalogo de entregables documentales.pdf`
- `Cómo documentar una lista de materiales BOM.pdf`
- `De la Simulación al Paper.pdf`
- `Escritura científica con LaTeX, MiKTeX y TeXstudio.pdf`
- `Flujogramas Modbus RTU.pdf`
- `Guia de estudio (1).pdf`
- `LABDST (SOFIA) - O26 - Definición de Eje Técnico de SC.pdf`
- `Lista de Cotejo D-Lab - Sofia.pdf`
- `Metodología D-LAB.pdf`
- `Modelado cinemático.pdf`
- `Presentación del LabDST.pdf`
- `Protocolo ModBus.pdf`
- `Referencias Bibliográficas, Matriz Comparativa y Benchmarking.pdf`
- `Sofia003-E001-04.pdf`
- `Sofia003-E001-04_2.pdf`
- `applsci-14-08171.pdf`
- `applsci-15-05383.pdf`
- `modbus_master.ino`
- `modbus_slave.ino`
- `plantilla_IEEE_LabDST.zip`
- `technologies-13-00404.pdf`
- `technologies-14-00223-v2.pdf`
