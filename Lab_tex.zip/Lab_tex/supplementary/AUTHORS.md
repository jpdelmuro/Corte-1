# Authorship and document version record

Document: Vision-Guided Expressive Motion for SOFIA: Technology Analysis and Preliminary System Design

Version: 0.1

Preparation date: 2026-09-21

Origin of the following names and their order: supplied Assignment 1 report.
The record preserves existing authorship information; it does not establish
new contributions or imply approval of this manuscript by every person.

| Listed author | Individual contribution | Approval of v0.1 | Conflict declaration |
| --- | --- | --- | --- |
| Aldo Mauricio Ocampo Martín | Team confirmation pending | Pending | Pending |
| Oscar Said Navarro Camarena | Team confirmation pending | Pending | Pending |
| Ignacio Gabriel Villaseñor Cervantes | Team confirmation pending | Pending | Pending |
| Juan Pablo Del Muro Quintero | Team confirmation pending | Pending | Pending |
| Guillermo Alejandro Romero Vazquez | Team confirmation pending | Pending | Pending |
| Jorge A. Lizárraga | Team confirmation pending | Pending | Pending |
| Graciela Baca | Team confirmation pending | Pending | Pending |
| Luis Enrique González-Jiménez | Team confirmation pending | Pending | Pending |
| Luis F. Luque-Vega | Team confirmation pending | Pending | Pending |

Suggested contribution categories to confirm from actual work: conceptualization,
methodology, software, formal analysis, investigation, validation, resources,
data curation, visualization, drafting, review/editing, supervision, and project
administration. Do not select categories solely from author order.

AI assistance is disclosed in the manuscript. It is not an authorship entry.

GitHub repository: not created or updated in this task.

Commit identifier: not applicable; GitHub work deferred by the user.

The course's GitHub authorship/version requirement remains outstanding.
