# Acquisition forms and data interpretation

The acquisition and calibration CSVs are intentionally empty forms, except
for proposed unit/channel identifiers. Empty measurements mean **not yet
measured**, never zero. The numerical CSV files are a separate evidence
class and must not be merged into a physical-experiment dataset.

## Files

- `experiment_log_template.csv`: one row per observed system sample/event.
- `servo_calibration_template.csv`: one row per servo calibration point.
- `run_configuration_template.json`: configuration and instrument metadata.
- `panel_coordinates.csv`: exact synthetic geometry for M1/M3.
- `kinematic_microtest.csv`: 800 direction evaluations, ideal mechanism.
- `boundary_microtest.csv`: six explicit solver boundary cases.
- `filter_microtest.csv`: 60 synthetic samples after a 30-degree step.
- `heart_wave_microtest.csv`: 181 times x 16 units over 6 seconds.
- `numerical_metrics.json`: reproducible numerical summary.

## Units and timing

All `_mm` fields are millimeters, `_deg` are degrees, `_s` are seconds,
`_V` are volts, `_A` are amperes, and `_lux` are lux.
`time_host_monotonic_s` is a monotonic host clock, not a wall-clock date.
Do not subtract an unsynchronized microcontroller timestamp from a host
timestamp. Record an explicit clock mapping or use host round-trip timings.

`command_q1_deg` and `command_q2_deg` are requested joint positions.
`measured_q1_deg` and `measured_q2_deg` must come from independent sensing;
do not copy PWM-derived commanded values into these columns.

The proposed mapping uses PCA9685 0x40 for units 1-8 and 0x41 for units
9-16. For each unit, local channels 2k and 2k+1 command q1 and q2,
where k is the zero-based index within that group of eight. This mapping
is proposed, not extracted from the unprovided reference PCB schematic.

Record the actual firmware mapping if different. Calibrate direction sign,
neutral offset, pulse endpoints, and mechanical limits before assigning
physical angle meanings to those channels.

## Participant protocol

Use pseudonyms, separate development and evaluation participants, and keep
video only when permitted by the documented consent process. A posture
label is ground truth only if independently annotated; the system's own
prediction cannot serve as its ground truth. Record missed and extra events,
not only successful detections.
