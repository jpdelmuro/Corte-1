# SOFIA: Discover-Learn IEEE article

Version 0.1 | 2026-09-21 | English manuscript

Main document: `plantilla_IEEE_LabDST.tex`.
The supplied LabDST template's IEEEtran journal class and two-column layout
are retained. The unused `lettersize` option was corrected to `letterpaper`.
Only the two substantive sections required for this submission are written:
Introduction (including Related Work), and Materials and Methods. The
later Apply/Build-and-Validate sections are intentionally not filled with
unperformed experiments.

## Compile the article

With a normal TeX Live or MiKTeX installation, open a terminal in this folder:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error plantilla_IEEE_LabDST.tex
```

Alternatively:

```sh
pdflatex -interaction=nonstopmode -halt-on-error plantilla_IEEE_LabDST.tex
bibtex plantilla_IEEE_LabDST
pdflatex -interaction=nonstopmode -halt-on-error plantilla_IEEE_LabDST.tex
pdflatex -interaction=nonstopmode -halt-on-error plantilla_IEEE_LabDST.tex
```

For Overleaf, upload this ZIP as a project, set
`plantilla_IEEE_LabDST.tex` as the main file and choose pdfLaTeX.
Python is not needed to compile the manuscript: all figure PDFs and the
small numerical-values TeX file are included. No shell escape or external
image downloads are required.

`IEEEtran.cls` and `IEEEtran.bst` are included. Other packages are standard
TeX distribution packages: fontenc, inputenc, amsmath, amsfonts, array,
graphicx, cite, url, xcolor, booktabs, tabularx, microtype, and hyperref.
The included class and bibliography style retain their original license
headers. The class comes from the user's supplied template; the style is
the unmodified IEEEtran BibTeX style obtained from CTAN.

## Package contents

- `plantilla_IEEE_LabDST.tex`: complete article source.
- `bibliography.bib`: twenty references in citation order after BibTeX.
- `IEEEtran.cls`, `IEEEtran.bst`: document and bibliography styles.
- `figures/`: two original vector diagrams used by the manuscript.
- `tools/numerical_checks.py`: repeatable mathematical microtests.
- `tools/make_figures.py`: optional regeneration of figures.
- `supplementary/`: actual numerical outputs, source register, literature
  matrix, review log, authorship record, and empty acquisition forms.
- `SOFIA_Discover_Learn_IEEE.pdf`: compiled reading copy.
- `BUILD_VERIFICATION.txt`: fresh-build check for this source package.
- `MANIFEST_SHA256.txt`: integrity hashes of the packaged content.

## Reproduce the numerical checks

```sh
python3 tools/numerical_checks.py
```

Only Python 3's standard library is required. The script overwrites its own
numerical CSV/JSON/TeX outputs under `supplementary/`. It does not access a
camera, network, serial port, or robot. The checks independently implement
the paper's ideal equations; they are not the original MATLAB code.

To regenerate the diagrams, install matplotlib and run:

```sh
python3 tools/make_figures.py
```

## Evidence and items the team must confirm

The two uploaded Assignment 1 PDFs are identical. The original report's
simulation numbers are attributed to that report; this package's numerical
results are labeled separately. There are no fabricated physical or
participant measurements. Design thresholds, the five-gesture vocabulary,
the Windows host stack, the alternative RS-485 interface, and the small
heart-wave amplitude are proposals for team review, not claims about
changes already made to the demonstrator.

Before formal submission, confirm the carried-forward author list,
individual contributions, and conflict declaration in `supplementary/AUTHORS.md`.
Integrate the supplied review record into the team's official logbook;
this package does not claim to reconstruct past laboratory attendance or
individual work. The manuscript states these administrative limitations.

GitHub work is explicitly deferred. No repository was created or modified,
no commit was made, and no public URL is claimed. The local version label
does not satisfy the course's eventual GitHub requirement by itself.

Physical power, torque, servo calibration, full-CAD clearance, camera
performance, and communication tests remain future measurements. Complete
the corresponding evidence before changing a proposed criterion into a
claim of compliance.
